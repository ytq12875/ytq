# -*- coding: utf-8 -*-

__author__ = 'STEVE'
__tag__ = "LeetCode"
__status__ == "Accepted"


class Solution:
    # @param x, an integer
    # @return an integer
    def sqrt(self, x):
        return int(x**0.5)
