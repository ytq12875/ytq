Leetcode
========

Leetcode of my own. (Python)



Try to collect problems...

11-18  it seemed Leetcode published Premium mode for new problems.

