
# coding: utf-8


import turtle


def o(msg=None):
    print(('*' * 30 + str(msg) + '*' * 30).center(80))


def move_right(x, y):
    return x + 1, y


def move_down(x, y):
    return x, y - 1


def move_left(x, y):
    return x - 1, y


def move_up(x, y):
    return x, y + 1

moves = [move_right, move_down, move_left, move_up]


def gen_points(end):
    from itertools import cycle
    _moves = cycle(moves)
    n = 1
    pos = 0, 0
    times_to_move = 1
    yield n, pos

    while True:
        for _ in range(2):
            move = next(_moves)
            for _ in range(times_to_move):
                if n >= end:
                    return
                pos = move(*pos)
                n += 1
                yield n, pos
        times_to_move += 1

print(list(gen_points(25)))


o()
