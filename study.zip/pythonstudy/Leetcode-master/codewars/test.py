print(ord('a'))
print(ord('h'))
