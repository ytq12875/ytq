def spread(func, args):
    return func(*args)


'Hurt me...'