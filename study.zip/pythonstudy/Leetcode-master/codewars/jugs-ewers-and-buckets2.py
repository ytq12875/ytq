

# https://gist.github.com/douglas-vaz/5331386



data = '''Year    County      Item        Value
1989    BILLINGS    BARLEY      6000
1989    GOLDEN      CORN        1700
1989    SLOPE       FLAXSEED    100
1990    BILLINGS    BARLEY      15000
1990    GOLDEN      CORN        300
1990    SLOPE       FLAXSEED    500
'''

