def copy_list(l):
  return list(l)



import numpy as np
_list = [1,2,3,4,5]
print(np.array(_list))