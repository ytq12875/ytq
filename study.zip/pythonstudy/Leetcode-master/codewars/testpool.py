__author__ = 'STEVE'

x = 0
print eval('x = 1')
print x