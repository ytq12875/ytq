' mongodb id and timestamp'

from datetime import datetime

print(datetime.time())

