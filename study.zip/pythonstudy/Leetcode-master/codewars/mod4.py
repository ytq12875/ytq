
'mod4 Regex'

'确认是4的倍数'

import re
class Mod:
  mod4 = re.compile('.*\[[+-]?([048]|\d*([02468][048]|[13579][26]))\]')