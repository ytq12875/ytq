

text = 'The turtle is leaving.'

import re

pattern = re.comp