def gcd(a, b):
    import fractions
    return fractions.gcd(a, b)

print(gcd(10, 12))