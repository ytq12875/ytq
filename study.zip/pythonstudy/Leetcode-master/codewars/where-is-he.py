def where_is_he(p, bef, aft):
    return min(p - bef, aft + 1)