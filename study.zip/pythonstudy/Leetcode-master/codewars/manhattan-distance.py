def manhattan_distance(pA, pB):
    return abs(pA[0] - pB[0]) + abs(pA[1] - pB[1]) 