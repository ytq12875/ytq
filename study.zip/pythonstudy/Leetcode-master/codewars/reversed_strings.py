def solution(str):
    # return ''.join(str[::-1])
    return str[::-1]


print(solution('word'))